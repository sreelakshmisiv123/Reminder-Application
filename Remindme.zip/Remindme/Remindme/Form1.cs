﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Remindme
{
    public partial class Form1 : Form
    {
        SqlDataAdapter adapt;

        
        public Form1()
        {
            InitializeComponent();
        }
        public string conString = "Data Source=NBPRGLAB017\\SQLA;Initial Catalog=reminder;User ID=sa;Password=admin123";

        private void Form1_Load(object sender, EventArgs e)
        {
            timepick.Format = DateTimePickerFormat.Time;
            timepick.ShowUpDown = true;
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            if (con.State == System.Data.ConnectionState.Open)
            {
                string q1 = "SELECT datee FROM tbevent";
                string q2= "SELECT time FROM tbevent";
                SqlCommand cmd = new SqlCommand(q1, con);
                SqlCommand cmd1 = new SqlCommand(q2, con);



                cmd.ExecuteNonQuery();
                
                con.Close();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(conString);
            con.Open();
            if (con.State == System.Data.ConnectionState.Open)
            {
                string q = "INSERT INTO tbevent(datee,time,event)VALUES('" + datepick1.Value.Date + "','" + timepick.Text + "','" + txtevent.Text + "')";
                SqlCommand cmd = new SqlCommand(q, con);

                cmd.ExecuteNonQuery();
              
                con.Close();
            }
             if (txtevent.Text== "")
            {
                MessageBox.Show("please insert all values");
            }
            else
            {
                MessageBox.Show("successfull..");
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {

            displaydata();
        }
        private void displaydata()
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from tbevent", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
            

        private void button3_Click(object sender, EventArgs e)
        
        {
            
                 SqlConnection con = new SqlConnection(conString);
                con.Open();
                if (con.State == System.Data.ConnectionState.Open)
                {
                    string q = "UPDATE tbevent SET datee ='" + datepick1.Value.Date + "',time='" + timepick.Text + "',event='" + txtevent.Text + "' where id=" + textBox1.Text + "";

                    SqlCommand cmd = new SqlCommand(q, con);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show(" update Succesfull");
                    displaydata();
                    con.Close();
                }
            
            
            
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString(); 
            datepick1.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            timepick.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtevent.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();  
        }

        private void timepick_ValueChanged(object sender, EventArgs e)
        {
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            datepick1.ResetText();
            timepick.ResetText();
            txtevent.Clear();
        }
    }
    }

