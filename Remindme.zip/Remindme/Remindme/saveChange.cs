﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Remindme
{
    public partial class saveChange : Form
    {
        public saveChange()
        {
            InitializeComponent();
        }
        public string conString = "Data Source=NBPRGLAB017\\SQLA;Initial Catalog=reminder;User ID=sa;Password=admin123";

        private void saveChange_Load(object sender, EventArgs e)
        {
            dateTimePicker2.Format = DateTimePickerFormat.Time;
            dateTimePicker2.ShowUpDown = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            if (con.State == System.Data.ConnectionState.Open)
            {
                string q = "SELECT * FROM tbevent WHERE datee='" + dateTimePicker1.Value.Date + "'";

                SqlCommand cmd = new SqlCommand(q, con);

                cmd.ExecuteNonQuery();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    dateTimePicker2.Text = dr.GetValue(2).ToString();
                    textBox1.Text = dr.GetValue(3).ToString();
                }
                else
                {

                    MessageBox.Show(" Not found");
                }
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            if (con.State == System.Data.ConnectionState.Open)
            {
                string q = "UPDATE tbevent SET datee ='" + dateTimePicker1.Value.Date + "',time='" + dateTimePicker1.Value.Date + "',event='" + textBox1.Text + "'";

                SqlCommand cmd = new SqlCommand(q, con);

                cmd.ExecuteNonQuery();
                MessageBox.Show(" update Succesfull");
                con.Close();
            }
        }
    }
}
